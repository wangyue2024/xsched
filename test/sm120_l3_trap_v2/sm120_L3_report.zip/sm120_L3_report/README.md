# sm120 Level-3（trap）进展材料

> 日期：2026-10-27　事实基线：`FINDINGS_ZH.md` **§1–§54（2026-10-27）**
> 平台：RTX 5060（sm_120）｜驱动 595.99.02（开源内核模块 + GSP）｜CUDA 12.9
> 对照：RTX 3090（sm86 / 570.124.04）、A100（sm80 / 550.107.02）、RTX 5090（sm_120 / 595.71.05）

---

## 0. 三分钟摘要

1. **可用的 Level-3 已交付（GDB backend）**：通过 cuda-gdb 冻结/恢复运行中的进程，
   设备静止 116 ms、预热后 attach ~23 ms、`Resume=1`，结果正确。
2. **trap 原语已打通**：能定位活体 `.text.traphandler`、注入 SASS、观察到签名 `0x5aa5`、
   把 8 s 内核在 0.234 s 内 kill 掉且 `cudaSuccess`；受管内核可被 RM `0317` 停住
   （设备真正冻结 0.204 ms，`Suspend` 返回 27–30 ms 是驱动 teardown）。
3. **论文方法在 sm86/570 上复现成功**：同一套上游 XSched 代码，`level 3` p50 **230–241 µs**、
   restore 93–127 µs，200 次 suspend/resume 后 16M 元素 `bad=0`。
   ⇒ **不是 Blackwell 架构不支持 trap**，差别落在 595 驱动对 sm120 关闭了 regops 入口。
4. **sm120/595 的根因是四道锁**：① 带内触发 `0x419e84` 被启动期 `pGpu+0x911` 关闭；
   ② 请求/判据只有事件可分（`0317=0x1`、`launch=0x8`），没有 per-suspend target；
   ③ handler 的 host→trap 数据通道不存在（驱动 pbuf 在 0317 陷阱里全 0、store 不共享）；
   ④ 恢复归 `libcudadebugger` 调试器状态机（0318 阻塞、裸 EXIT 破坏重放）。
5. **建议**：交付优先锁定 GDB backend；研究优先做进程内调试 agent；论文复现优先换
   sm86/570（已验证）或 GV100。

## 1. 关键数字

| 项 | 数字 | 说明 |
|---|---|---|
| 论文 GV100 Lv3 | **32 µs**（P99） | OSDI'25 §7.3，T=0.5 ms |
| 3090 sm86/570 复现 | **p50 230–241 µs** | 上游原样，带 shim；p99 0.42–2.8 ms |
| 3090 正确性 | **bad=0 / 16M** | 200 次抢占后 |
| sm120 GDB | **116 ms** 设备静止 | attach ~23 ms，`Resume=1` |
| sm120 trap 设备冻结 | **0.204 ms** | 会话预建 |
| sm120 trap `Suspend` 返回 | **22.9 ms** | 驱动 teardown + stream 同步 |
| sm120 trap cancel | **27–30 ms** | 受管默认 |
| sm120 kill（standalone） | 8 s → **0.234 s** | `cudaSuccess` |
| 判据 | `0317=0x1`、`launch=0x8` | 仅事件可分，无 target |
| 驱动 pbuf（0317 陷阱） | `+0/+4/+8 = 0` | 可读不 fault；store 不与驱动共享 |

## 2. 材料地图（本包与仓库同构，报告里的相对链接可直接打开）

按**论证框架**排序：结论 → 证据 → 替代形态 → 下一步。

| 路径 | 内容 | 建议 |
|---|---|---|
| `report/00-总索引与结论全表.md` | **总入口**：文档地图、C1–C10、E1–E12、关键数字、旧结论更正、覆盖审计、资产地图、未覆盖项 | 先读这份 |
| `report/01-成果汇报.md` | **10–15 分钟汇报稿**：一页结论、三个核心观点（02+03 入口 / 04 替代 / 05 下一步）、A/B/5090、需求审计、决策、8 页讲法 | 先读这份 |
| `report/02-中断入口.md` | **观点一（证据链）**："中断入口换了"：论文原文、sm86 代码/payload、A/B、**`0x20800122` 接口层 / `pGpu+0x911` 开关层 / 绕过分析**、0317 四态、上下文实验、**5090/595.71 实测**、证据矩阵、可证伪条件 | 核对证据/讨论根因时读 |
| `report/03-核心结论.md` | **观点一（结论）**：595/Blackwell 关闭 reg-op → 论文带内 L3 在当前 sm120/595 不可实现；精确表述、证据强度、反方回应、可证伪条件、汇报口径 | 汇报主结论时读 |
| `report/04-替代形态.md` | **观点二：GDB / 0317**：结果层 L3 替代、机制/条件/适用、**0317 四态与 park 入口/不可释放**、寄存器/malloc/幂等、显存/让出、XQueue 重放、0318≠重放、新调度契约、证据链 | 讲"我们做了什么"时读 |
| `report/05-下一步论点.md` | **观点三：四个论点 + 路线图**：N1 三段耦合/2.5 段、N2 0317/cave/reason、N3 target 是通道缺口、N4 选择性≠延迟；限制 L1–L12、P1–P6、三个近期实验 | 讨论下一步时读 |
| `report/06-问答.md` | Q1–Q12：进度、sm120 与之前架构最大不同、带内触发是"不存在"还是"没找到"、0317 是什么、为什么有时 cancel/park/no-op、27 ms 与 116 ms 花在哪、handler 能读能写什么、既然 reason 可区分为什么还不行、还差什么、sm120 能不能做 L3、为什么 32 µs / 229 µs / 27 ms | 讨论/追问时查 |
| `report/10-开放问题与假设清单.md` | **25 条开放问题/假设**：Q-A 入口、Q-B 通道、Q-C 恢复、Q-D 平台、Q-E 工程、Q-F 论文；Top 10、决策门、不要再试、关闭规则 | 规划下一步时读 |
| `report/kb/README.md` | kb 路由、关键词、ID 规则 | 检索入口 |
| `report/kb/ABI.md` | **sm120 trap/driver ABI 参考手册**：地址图、handler/reason/SASS/cave、debugger params、pbuf/scratchpad、trap 内存语义、RM 0x83de/0x20800122、调试栈、版本矩阵、失败模式、工具、术语 | 做实现/逆向时查 |
| `report/kb/Methods.md` | **方法/证据/自更正/坑**：证据等级与"停住"三判据、方法目录、证据账本 E-01..E-12、自更正 C-01..C-06、坑 P-01..P-17 | 判断可信度/排错时查 |
| `report/kb/Runbook.md` | **构建/运行/移植/故障/资产**：环境矩阵、build、GDB/TRAP run、换驱动 checklist、故障树 F-01..F-12、资产 A-01..A-10 | 跑实验/排障时查 |
| `report/archive/01-成果汇报-完整版-2026-10-27.md` | 旧 14 节全量版（历史；旧编号 01–07） | 查历史细节时读 |
| `compendium/` | 七册总汇（README + 01 研究过程 / 02 路径与方法 / 03 机制与逆向 / 04 通道矩阵 / 05 工具与复现 / 06 结论与下一步 / 07 A-B 完整实测） | 想系统了解时读 |
| `FINDINGS_ZH.md` | 滚动实验日志 §1–§54：每轮实验的原始结论、证据、开关、复现命令 | **事实基线**，按章节查，不要线性读 |
| `RM_REVERSE_ZH.md` | RM ABI、`0x83de` 命令表、权限模型、cuda-gdb 时序 | 需要 RM 细节时读 |
| `L3_TRAP_SM120_REPORT_ZH.md` | 阶段总报告 + 目标达成审计更新 1–6 | 看"目标达成了哪些" |
| `evidence/live/` | 19 个关键现场日志（trap 签名、受管 suspend、NO_ICTX、debugger params、pbuf 读写、park、hostpoke、gdb cancel） | 逐条对应结论，见 `evidence/README_证据索引.md` |
| `evidence/ab_ampere/` | 3090 battery（L1/L2/L3×3/TSG）、正确性、去 shim、A100 失败、sm86 handler 实物、agent ioctl 0317 | A/B 证据 |
| `evidence/rtx5090_595_71/` | 5090 实测：regops 锁、GDB 冻结、活体 handler、0317 签名、kill/park 流程 | 2026-10-26 追加 |
| `code/` | 关键代码快照：HAL（trap_sm120/interrupt/cuda_queue）、arch/sm120.cpp、l3agent/l3qspin、复现脚本 | 可选，见 `code/README_代码索引.md` |

论文原文在仓库 `xsched/docs/xsched-osdi25.pdf`（未随包附带）。

## 3. 阅读顺序（建议）

- **10 分钟**：本文件 §0–§1 → `report/01-成果汇报.md` 的"一页结论/三个观点/需求审计"。
- **30 分钟**：`report/02-中断入口.md`（证据链）→ `report/03-核心结论.md`（结论边界）→ `report/04-替代形态.md`（能做什么/不能做什么）→ `report/05-下一步论点.md`（缺口与路线）。
- **追问准备**：`report/06-问答.md` 的 Q2、Q5、Q8、Q9、Q10。
- **深挖**：`compendium/03-机制与逆向.md`、`compendium/04-通道矩阵.md`、`compendium/07-A-B-完整实测.md`；原始数据查 `FINDINGS_ZH.md` 对应 §。

## 4. 口径与边界（重要）

- 本文区分三类陈述：**已验证事实**（有日志/代码）、**平台约束**（由实验穷尽得出）、
  **未验证/推断**（明确标注）。引用时请保持区分。
- "生产可用 L3" 指 **GDB freeze**，不是论文的 32 µs；"恢复"目前是 **kill + 队列重放**，
  不是原地续跑（计数会从头重跑）。
- 所有驱动偏移、handler 指纹、pbuf 布局**只对 595.99.02 有效**；换驱动版本必须先跑指纹校验。
- sm120 的"trap 上下文读全局内存返回 0"是**debugger-suspend trap** 的性质；
  论文那种**带内 trap** 在 sm120 上不可达，不能据此断言"sm120 的 handler 完全不能读全局内存"。
- 论文的 L3 没有单独的 host 写 target ID：触发按 queue，handler 用现场 `kernel_idx`
  和 `preempt_idx` 记账。sm120 上我们只有 context 级触发，所以"选择目标"才成为缺口。
- 旧结论有多次更正（`NO_PATCH` 语义、launch trap、reason 恒 0x1、"ST 写 pbuf 必 700"）；
  以 `FINDINGS_ZH.md` 最新章节为准，`report/kb/Methods.md` 的 C-01..C-06 有自更正清单。

## 5. 证据标准

任何"停住"结论都要求三个独立判据同时成立：**设备计数冻结、`Synchronize` 状态、
host 回读一致**。仅凭"`Suspend` 返回"或"stream 判完成"不算。

## 6. 备注

- 本包是**快照**，不含完整构建环境；`code/` 只是关键文件，复现需要完整仓库 + cuxtra/ipc。
- 个别深链（v1 归档 `sm120_l3_probe/`、`evidence/disasm/` 反汇编、`tools/`）未随包附带，
  不影响主结论；需要时可在完整仓库中查看。
- `run_l3qspin.sh suspend` 依赖 cuda-gdb 应答且本机偶发 700；现场演示建议用
  `run_l3kill.sh` / `run_l3hal.sh`，或直接展示 `evidence/live/` 的已落盘日志。
