# 证据索引

> 所有日志均为原始输出，未改动。完整现场日志（309 个）在仓库
> `test/sm120_l3_trap_v2/evidence/live/`，A/B 全量在 `evidence/ab_ampere/`。
> 下面只保留"每个结论至少一条"的最小集。

## sm120 现场（`live/`）

| 日志 | 证明什么 | 关键行 / 数字 |
|---|---|---|
| `exp_sig_rm0317.log` | 普通 CUDA 上下文里 RM `0317` 能进活体 handler，cave 执行 | 签名 `0x5aa5`、`reason=0x1`、内核继续 |
| `exp_managed_spin1.log` | 受管内核被 `0317` 停住（三级判据） | 计数冻结在 suspend 时刻、`Suspend` 返回 27–30 ms |
| `exp_no_ictx_instrmem.log` | `NO_ICTX_INSTRMEM` 下 0317 变 no-op；用于区分三态 | 内核自然跑完，不复位 |
| `exp_dbgparam_{170,178,180,188}.log` | handler 能读 launch 固定 debugger params | `0x170=0x02000000`、`0x178=0xb6c00200`、**`0x180=1`（kernel_idx）**、**`0x188=1`（killable）** |
| `exp_arm_sentinel_host.log` | 0317 陷阱的 reason（host 装入，无额外 launch） | 记录页 `0x1` |
| `exp_arm_sentinel_dev.log` | 设备 writer 内核自己的 launch trap reason | 记录页 `0x8` |
| `exp_arm_pbuf_cmd4.log` | 0317 陷阱里读驱动 pbuf 命令字 | `+4 = 0`（可读不 fault） |
| `exp_arm_pbuf_idx8.log` | 读 `preempt_idx` | `+8 = 0` |
| `exp_arm_pbuf_flag0.log` | 读 exit flag | `+0 = 0` |
| `exp_arm_pbuf_write_r2.log` | 0317 陷阱里对 pbuf+4 发 `ST.E` | 不 fault，记录页 `0x1` |
| `exp_arm_pbuf_write2.log` | 写 `cmd=2` 是否影响驱动 | 行为与写 1 相同（kill+replay、`cudaSuccess`）⇒ store 不与驱动共享 |
| `exp_reason_arm_exit.log` | reason 门控 + 裸 EXIT | launch 未误杀；0317 后 EXIT、`suspend 27.4 ms`；重放失败、final 700 |
| `exp_strace_park1.log` | CUDA init 前外部 tracer → 真 park | 计数冻结、`Synchronize` 不返回 |
| `exp_plaingdb_park1.log` | plain gdb（非 cuda-gdb）也能打开 park | 同上 |
| `exp_hostpoke_park1.log` | CPU 侧 pbuf 是 PROT_NONE/COW 零页 | mprotect 成功、读全 0、写后内核仍 park |
| `exp_gdb_cancel1.log` | cuda-gdb 在场时 0317 变成 cancel | 27.3 ms cancel |

## A/B（`ab_ampere/`）

| 日志 | 证明什么 | 关键数字 |
|---|---|---|
| `battery_3090/level3_1/2/3.log` | 3090 sm86/570 上游 L3 三次运行 | p50 230–241 µs、p99 0.42–2.8 ms、restore 93–127 µs |
| `battery_3090/level1.log` / `level2.log` / `level3_tsg.log` | 同机 L1 / L2 / TSG 对照 | 13.38 ms / 1.257 ms / 13.35 ms |
| `correct_sm86.log` | 正确性 | 200 次抢占后 16M 元素 `bad=0 -> OK` |
| `level3_sm86_noshim.log` | 去掉 shim 后退化 | 6–40 ms ⇒ 快路径依赖 managed launch |
| `level3_sm80_noshim.log` | A100 无 shim 慢路径 | 33–46 ms |
| `level3_tsg_a100_noshim.log` | A100 TSG 对照 | 0.58–55.7 ms |
| `sm86_agent_ioctl_0317.log` | cuda-gdb 的 0317/0318 序列与 cuxtra 触发是两条路径 | `0307 → 0317 → 0315/030c/0316 → 0318` |
| `sm86_handler.bin` / `a100_handler.bin` + dump | handler 实物 | 均 0x1200；`+0x3e0` 都是 `IADD3 R1,R1,-0x10,RZ` |

## 怎么复核

在完整仓库里：

```bash
cd xsched/test/sm120_l3_trap_v2
grep -E "signature|reason=0x1" evidence/live/exp_sig_rm0317.log
grep -E "counter=|suspend" evidence/live/exp_managed_spin1.log
grep -E "rec \+0x100|pbuf relocated" evidence/live/exp_arm_pbuf_*.log
./run_l3kill.sh          # 8 s -> ~0.234 s
./run_l3hal.sh           # GDB backend 回归
```

注意：`run_l3qspin.sh suspend` 依赖 cuda-gdb 应答，且这台机器上偶发 700；
汇报现场建议用上面这些已落盘日志，不要现场跑它。

## 5090（`rtx5090_595_71/`，2026-10-26）

| 日志 | 证明什么 | 关键结果 |
|---|---|---|
| `env.txt` | 平台 | RTX 5090 / sm_120 / 595.71.05 / CUDA 12.8 / Ubuntu 22.04 |
| `regops_read.log` | 锁测试 | PMC_BOOT_0、PTIMER 全 0，status 0x3a；read w/ channel status 0 但 value 0 |
| `regops_write.log` | 写触发 | `0x419e84` bit31 status 0x3a，无副作用 |
| `spin.log` / `gdb.log` | GDB 冻结 | 3 s hold 期间计数冻结（wall gap 3.08 s），detach 后继续 |
| `spinA.log` / `gdbA.log` | 3 s hold 复测 | 15 s spin 正常完成（done 位） |
| `find_live_handler.log` | handler 布局 | slot20 0x880/0x1300、do_pause 0/160 mismatch、base+0x15f0f00 |
| `target.log` / `agent.log` | 0317 签名 | fingerprint MATCH；签名 `0x5aa5/reason=0x1` |
| `target_kill.log` / `agent_kill.log` | kill 流程（8 s） | victim 8 s→3.395 s，但 sig 0/0；`devflag arm=0xffffffff`、PARKED、release 失败 |
| `campaign/env.txt` | 5090 完整环境 | GSP 595.71.05、open module、libcuda/libcudadebugger md5、CUDA 13.2/12.8、容器 caps |
| `campaign/spin_gdb.log` / `gdb.log` | GDB 3 s hold 复测 | counter 2.837M→2.907M，wall +3.12 s |
| `campaign/target_trap.log` / `agent_trap.log` | 0317 签名复测 | 0x5aa5/0x1，victim 12.5 s |
| `campaign/target_kill20.log` / `agent_kill20.log` | kill 流程（20 s） | victim 20 s→3.426 s；devflag 0xffffffff、PARKED；pbuf=base−0x8000000 |

> 注：`rtx5090_595_71/` 的 `drivers/`（libcuda 88 MB + libcudadebugger 12 MB）与 `bin/`
> 只保存在仓库 evidence 中，**不随本压缩包附带**；包内只有 `campaign/` 与早期日志。
