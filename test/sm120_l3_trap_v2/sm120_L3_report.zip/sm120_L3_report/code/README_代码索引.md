# 代码快照索引（可选）

> 这是汇报材料的**代码附录**，不是完整仓库。完整构建需要 cuxtra/ipc 子模块与
> XSched 的构建环境（见 `compendium/05-工具与复现.md`）。
> 路径以仓库根 `xsched/` 为基准。

| 快照文件 | 仓库路径 | 作用 |
|---|---|---|
| `level3/trap_sm120.cpp` | `platforms/cuda/hal/src/level3/trap_sm120.cpp` | sm120 trap backend：ioctl 拦截、0xd04 授权、arena/live handler 定位与 patch、cave、arm/trigger/resume、全部诊断探针（`XSCHED_SM120_TRAP_*`） |
| `level3/interrupt.cpp` | `platforms/cuda/hal/src/level3/interrupt.cpp` | `InterruptContext`：InstrMemAllocator、handler payload 安装、sm120 走 `TrapSm120Context::Trigger` |
| `level3/cuda_queue.cpp` | `platforms/cuda/hal/src/level3/cuda_queue.cpp` | `CudaQueueLv3Trap`：Suspend→Interrupt、Resume→Restore、kill 后重放 |
| `arch/sm120.cpp` | `platforms/cuda/hal/src/arch/sm120.cpp` | 上游 sm120 guardian/resume/trap payload（`trap_inject_instrs`，读 preempt buffer 的 exit flag / preempt_idx） |
| `probe/l3agent.cpp` | `test/sm120_l3_trap_v2/probe/l3agent.cpp` | 外部 agent：0x83de 会话、0317/0318、ptrace、shm |
| `probe/l3qspin.cu` | `test/sm120_l3_trap_v2/probe/l3qspin.cu` | 受管内核实验台（host-mapped 计数 + 设备完成字） |
| `scripts/run_l3qspin.sh` | `test/sm120_l3_trap_v2/run_l3qspin.sh` | 一键复现 suspend / kill / probe / noinstr |
| `scripts/run_l3kill.sh` | `test/sm120_l3_trap_v2/run_l3kill.sh` | standalone trap kill（8 s → 0.234 s） |
| `scripts/run_l3hal.sh` | `test/sm120_l3_trap_v2/run_l3hal.sh` | GDB backend 端到端回归 |

## 读代码的顺序

1. `arch/sm120.cpp` 的 `trap_inject_instrs`：先看论文 L3 payload 到底读什么、写什么；
2. `level3/interrupt.cpp`：看它怎么被装到 handler `+0x880`，以及 sm120 为什么走 0317；
3. `level3/trap_sm120.cpp`：看 live handler 定位、`+0x390` CALL、cave 8 槽、arm/trigger；
4. `level3/cuda_queue.cpp`：看 Suspend/Resume 与 kill 后重放；
5. `probe/l3agent.cpp` + `run_l3qspin.sh`：看 0317{1,0}/0318 与会话生命周期。

## 注意

- `trap_sm120.cpp` 里大量分支是**诊断用 env**（`XSCHED_SM120_TRAP_*`），默认不生效；
  生产路径仍是 `XSCHED_SM120_L3_BACKEND=GDB`。
- 驱动偏移/指纹只对 595.99.02 有效；换版本先跑指纹校验，否则 patch 点是错的。
